package cscart.demo;

import java.awt.Desktop.Action;
import java.time.Duration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class standalone {

	public static void main(String[] args) throws InterruptedException {

		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver(); // object of chromedriver
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(200));
		driver.manage().window().maximize();
		LandingPage loginpage = new LandingPage( driver);
		loginpage.goTo();
		loginpage.loginDemo("prudhwicabatchu@gmail.com");
		SearchProductsPage searchproductspage = new SearchProductsPage(driver);
		searchproductspage.searchproducts("Chocolate");
		searchproductspage.selectbrand("Armour LunchMakers");
		//List<WebElement> products =searchproductspage.getProductsList();	
		searchproductspage.addAllProductsToCart();
		Boolean result=searchproductspage.verifycountofproducts();
	    Assert.assertTrue(result);
		searchproductspage.clickcheckout();	
		CheckoutPage checkoutpage = new CheckoutPage (driver);
		checkoutpage.fillcustomerdetails("bommersheim","prudh@gmail.com" );
		checkoutpage.selectpayment("4912679345789");
		checkoutpage.placeorders();
		
		
	}

}


